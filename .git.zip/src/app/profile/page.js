
import DoctorProfile from'./components/DoctorProfile'
export default function page() {
  return (
<DoctorProfile/>
  )
}
