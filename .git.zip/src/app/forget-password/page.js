import ForgetPassword from "./component/ForgetPassword";


export default function page() {
  return (
  <ForgetPassword/>
  )
}
