import React from 'react'
import ResetPage from './components/resetPassword'
export default function page() {
  return (
    <ResetPage />
  )
}
