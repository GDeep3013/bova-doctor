import RegisterForm from "./components/RegisterForm";

export default function page() {
    return (
        <RegisterForm />
    )
}
