import LoginForm from './login/components/LoginForm';

export default function page() {
    return (
        <LoginForm />
          
    )
}
