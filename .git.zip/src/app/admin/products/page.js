
import Setting from "./components/settings"
export default function page() {
  return (
    <Setting/>
)
}
