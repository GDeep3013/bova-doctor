import DoctorCommissionSummary from "./components/DoctorCommissionSummary";

export default function page() {
    return (
        <DoctorCommissionSummary />
    )
}