import DoctorDetailsPage from "../components/DoctorDetailsPage";

export default function page() {
    return (
        <DoctorDetailsPage />
    )
}