'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import AppLayout from 'components/Applayout';
import Loader from 'components/loader';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend);

export default function DoctorDetailsPage() {
  const { id } = useParams();
  const router = useRouter();
  const [doctor, setDoctor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedYear, setSelectedYear] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');

  const formatCurrency = (value) => Number(value || 0).toFixed(2);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/doctors/doctor-sales-summary/${id}`)
      .then((res) => {
        if (!res.ok) throw new Error('Doctor not found');
        return res.json();
      })
      .then((data) => {
        setDoctor(data);
        setLoading(false);
        const years = Object.keys(data.monthly_summary || {}).map((k) => k.split('-')[0]);
        const latestYear = years.sort().pop();
        setSelectedYear(latestYear);
      })
      .catch((error) => {
        console.error('Error fetching doctor data:', error);
        setLoading(false);
        setDoctor(null);
      });
  }, [id]);

  const getChartData = () => {
    if (!doctor?.monthly_summary) return { labels: [], datasets: [] };

    // MONTHLY VIEW
    if (!selectedMonth) {
      const monthLabels = Array.from({ length: 12 }, (_, i) => `${selectedYear}-${i + 1}`);
      const salesData = Array(12).fill(0);
      const commissionData = Array(12).fill(0);

      Object.entries(doctor.monthly_summary).forEach(([key, value]) => {
        const [year, month] = key.split('-');
        if (year === selectedYear) {
          const index = parseInt(month, 10) - 1;
          salesData[index] = Number(value.total_sold.toFixed(2));
          commissionData[index] = Number(value.total_commission.toFixed(2));
        }
      });

      return {
        labels: monthLabels,
        datasets: [
          {
            label: 'Total Sold ($)',
            data: salesData,
            borderColor: '#4B9EFF',
            backgroundColor: 'rgba(75, 155, 255, 0.2)',
            tension: 0.4,
            fill: true,
          },
          {
            label: 'Total Commission ($)',
            data: commissionData,
            borderColor: '#4ADE80',
            backgroundColor: 'rgba(74, 222, 128, 0.2)',
            tension: 0.4,
            fill: true,
          },
        ],
      };
    }

    // DAILY VIEW
    const daysInMonth = new Date(parseInt(selectedYear), parseInt(selectedMonth), 0).getDate();
    const dailyLabels = Array.from({ length: daysInMonth }, (_, i) => i + 1);
    const salesData = Array(daysInMonth).fill(0);
    const commissionData = Array(daysInMonth).fill(0);

    doctor.patients.forEach((patient) => {
      patient.payments.forEach((payment) => {
        const date = new Date(payment.date);
        const year = date.getFullYear().toString();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate();

        if (year === selectedYear && month === selectedMonth) {
          const index = day - 1;
          salesData[index] += payment.amount_paid;
          commissionData[index] += payment.commission_earned;
        }
      });
    });

    return {
      labels: dailyLabels,
      datasets: [
        {
          label: 'Daily Sold ($)',
          data: salesData,
          borderColor: '#4B9EFF',
          backgroundColor: 'rgba(75, 155, 255, 0.2)',
          tension: 0.4,
          fill: true,
        },
        {
          label: 'Daily Commission ($)',
          data: commissionData,
          borderColor: '#4ADE80',
          backgroundColor: 'rgba(74, 222, 128, 0.2)',
          tension: 0.4,
          fill: true,
        },
      ],
    };
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      tooltip: {
        callbacks: {
          label: function (context) {
            return `$${context.raw}`;
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value) => `$${value}`,
        },
      },
    },
  };

  const allYears = doctor?.monthly_summary
    ? Array.from(new Set(Object.keys(doctor.monthly_summary).map((k) => k.split('-')[0])))
    : [];

  return (
    <AppLayout>
      <div className="mx-auto">
        {loading ? (
          <Loader />
        ) : !doctor ? (
          <p className="p-4 text-red-500">Doctor not found</p>
        ) : (
          <>
                
                    <div className='flex justify-end'>
            <button class="bg-[#2c444b] text-white text-base px-6 py-2 rounded-lg hover:bg-[#0b1214]">
  Review Plan (2)
</button>
          </div>
          <div className="flex justify-between items-end mt-[16px] mb-4">
                  <div>
                    <h2 className='page-title pt-2 text-2xl'>Doctor's Sales Summary</h2>
            <h1 className="page-title pt-2 text-xl font-bold text-[#53595b]">{doctor.doctor_name} - Summary</h1>
            
              <button className="text-gray-600 text-sm mb-4 text-left" onClick={() => { router.back() }}>&lt; Back</button>
            </div>
            <div>
            <div class="flex items-center space-x-2">
  <label class="text-gray-600 uppercase text-sm tracking-wider">Search</label>
  <input
    type="text"
    placeholder=""
    class="border border-gray-300 rounded-[7px] px-4 py-1 outline-none focus:ring-none focus:ring-blue-400"
  />
</div>
            </div> 
           </div>

            {/* Filters */}
            {/* <div className="flex gap-4 mb-4"> 
                <select
                  className="border p-2 rounded select-month select-arrow"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                >
                  <option value="">Monthly Summary</option>
                  {Array.from({ length: 12 }, (_, i) => (
                    <option key={i + 1} value={String(i + 1).padStart(2, '0')}>
                      {new Date(0, i).toLocaleString('default', { month: 'long' })}
                    </option>
                  ))}
                </select>
              
            </div> */}

            {/* Chart */}
            {/* <div className="mb-8 bg-white p-4 rounded shadow">
              <h3 className="font-semibold text-lg mb-4">
                {selectedMonth
                  ? `Daily Summary - ${selectedYear}-${selectedMonth}`
                  : `Monthly Summary - ${selectedYear}`}
              </h3>
              <Line data={getChartData()} options={chartOptions} height={100} />
            </div> */}

            {/* Patient Details Table */}
            <div className="bg-white p-4 rounded shadow">
                  <h3 className="font-semibold text-lg mb-2">Patient Details</h3>
                  
                  
              <table className="w-full border border-gray-200 text-sm">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2 border">Patient Name</th>
                    <th className="p-2 border">Date</th>
                    <th className="p-2 border">Amount Paid ($)</th>
                    <th className="p-2 border">Commission Rate (%)</th>
                    <th className="p-2 border">Commission Earned ($)</th>
                  </tr>
                </thead>
                <tbody>
                  {doctor.patients.map((patient, i) =>
                    patient.payments
                      .filter((payment) => {
                        const date = new Date(payment.date);
                        const year = date.getFullYear().toString();
                        const month = (date.getMonth() + 1).toString().padStart(2, '0');
                        return (
                          year === selectedYear &&
                          (!selectedMonth || month === selectedMonth)
                        );
                      })
                      .map((payment, j) => (
                        <tr key={`${i}-${j}`} className="hover:bg-gray-50">
                          <td className="p-2 border">{patient.patient_name}</td>
                          <td className="p-2 border">{new Date(payment.date).toLocaleDateString()}</td>
                          <td className="p-2 border">${formatCurrency(payment.amount_paid)}</td>
                          <td className="p-2 border">{payment.commission_rate}%</td>
                          <td className="p-2 border">${formatCurrency(payment.commission_earned)}</td>
                        </tr>
                      ))
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </AppLayout>
  );
}
