
import ThemeCustomized from './components/ThemeCustomized'

export default function page() {
  return (
  <ThemeCustomized/>
  )
}
