import PatientDetial from "../../components/PatientDetail";


export default function page() {
  return (
 <PatientDetial/>
  )
}
