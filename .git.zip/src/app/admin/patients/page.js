import React from 'react'
import PatientList from './components/PatientListing'

export default function page() {
  return (
 <PatientList/>
  )
}
