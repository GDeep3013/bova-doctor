import DoctorListing from "./components/DoctorListing";

export default function page() {
    return (
      <DoctorListing />  
    )
}
