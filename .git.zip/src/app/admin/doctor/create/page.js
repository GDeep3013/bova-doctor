import CreateDoctor  from '../components/CreateDoctor'

export default function Page() {
  return (
    <CreateDoctor/>
  )
}
