import EditDoctor from '../../components/EditDoctor'

export default function page() {
  return (
<EditDoctor/>
  )
}
