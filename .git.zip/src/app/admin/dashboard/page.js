
import AdminDashboard from './components/AdminDashboard'

export default function page() {
  return (
  <AdminDashboard/>
  )
}

