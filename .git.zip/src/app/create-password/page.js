import React from 'react'
import CreatePassword from './components/CreatePassword'
export default function page() {
    return (
      <CreatePassword/>
  )
}
