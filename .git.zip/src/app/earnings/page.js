import Earnings from "./component/earnings";


export default function page() {
  return (
  <Earnings />
  )
}
