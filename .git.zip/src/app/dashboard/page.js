
import DoctorDashboard from './components/DoctorDashboard'

export default function page() {
  return (
  <DoctorDashboard/>
  )
}

