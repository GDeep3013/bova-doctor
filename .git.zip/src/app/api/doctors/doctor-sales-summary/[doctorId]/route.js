import connectDB from '../../../../../db/db';
import Doctor from '../../../../../models/Doctor';
import Patient from '../../../../../models/patient';
import Plan from '../../../../../models/plan';

export async function GET(req, { params }) {
  await connectDB();
  const { doctorId } = params;

  try {
    // Fetch doctor
    const doctor = await Doctor.findOne({ _id: doctorId, userType: 'Doctor' }).lean();
    if (!doctor) {
      return new Response('Doctor not found', { status: 404 });
    }

    // Get all patients for this doctor
    const patients = await Patient.find({ doctorId }).lean();

    // Map patients for quick access
    const patientMap = {};
    for (const patient of patients) {
      patientMap[patient._id.toString()] = patient;
    }

    // Get plans for those patients
    const patientIds = Object.keys(patientMap);
    const plans = await Plan.find({
      patient_id: { $in: patientIds },
      planStatus: 'ordered',
    }).lean();

    // Initialize summary
    let totalSold = 0;
    let totalCommission = 0;
    const monthlySummary = {};
    const patientPaymentsMap = {};
    let totalPatients = 0;

    for (const plan of plans) {
      const patient = patientMap[plan.patient_id?.toString()];
      if (!patient) continue;

      // Calculate amounts
      let totalItemAmount = 0;
      for (const item of plan.items) {
        const price = parseFloat(item.price || '0');
        const quantity = item.quantity || 0;
        totalItemAmount += price * quantity;
      }

      const discount = plan.discount || 0;
      const amountPaid = totalItemAmount - discount;
      const commissionRate = plan.doctorCommission || 0;
      const commissionEarned = amountPaid * commissionRate / 100;

      // Monthly key
      const date = new Date(plan.createdAt);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

      if (!monthlySummary[monthKey]) {
        monthlySummary[monthKey] = { total_sold: 0, total_commission: 0 };
      }
      monthlySummary[monthKey].total_sold += amountPaid;
      monthlySummary[monthKey].total_commission += commissionEarned;

      totalSold += amountPaid;
      totalCommission += commissionEarned;

      // Patient payments
      const patientKey = `${patient.firstName} ${patient.lastName}`;
      if (!patientPaymentsMap[patientKey]) {
        patientPaymentsMap[patientKey] = {
          patient_name: patientKey,
          payments: [],
        };
        totalPatients += 1;
      }

      patientPaymentsMap[patientKey].payments.push({
        date: plan.createdAt,
        amount_paid: amountPaid,
        commission_rate: commissionRate,
        commission_earned: commissionEarned,
      });
    }

    const result = {
      id: doctor._id,
      doctor_name: `${doctor.firstName} ${doctor.lastName}`,
      email: doctor.email,
      phone: doctor.phone,
      clinicName: doctor.clinicName,
      specialty: doctor.specialty,
      commissionPercentage: doctor.commissionPercentage,
      total_sold: totalSold,
      total_commission: totalCommission.toFixed(2),
      total_patients: totalPatients,
      monthly_summary: monthlySummary,
      patients: Object.values(patientPaymentsMap),
    };

    return Response.json(result);
  } catch (error) {
    console.error('Error generating doctor report by ID:', error);
    return new Response('Internal Server Error', { status: 500 });
  }
}
