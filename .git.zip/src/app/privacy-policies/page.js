
import React from 'react'
import PrivacyPolicy from './components/privacy-policies'
export default function page() {
  return (
  <PrivacyPolicy />
  )
}
