import PatientDetial from "../../components/PatientDetial";



export default function page() {
  return (
  <PatientDetial/>
  )
}
