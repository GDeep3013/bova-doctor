

import AddPatient from "../components/AddPatient";


export default function page() {
  return (
    <AddPatient/>
  )
}
