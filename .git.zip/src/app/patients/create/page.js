
import CreatePatients from '../components/CreatePatients'
export default function page() {
    return (
    <CreatePatients/>  
  )
}
