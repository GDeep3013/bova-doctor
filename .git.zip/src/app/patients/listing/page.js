import PatientList from "../components/PatientList";


export default function page() {
  return (
    <PatientList/>
  )
}
