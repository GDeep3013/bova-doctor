import EditPatients from "../../components/EditPaitents";



export default function page() {
    return (
        <EditPatients />
    )
}
