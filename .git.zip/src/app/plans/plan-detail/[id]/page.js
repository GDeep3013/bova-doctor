
import PlanDetail from '../../components/PlanDetial'
export default function page() {
  return (
<PlanDetail/>
  )
}
