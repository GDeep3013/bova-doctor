
import ReviewPlan from '../components/ReviewPlan'

export default function page() {
  return (
    <ReviewPlan/>
  )
}
