import SavedPlan from "../components/SavedPlan";


export default function page() {
    return (
        <SavedPlan />
    )
}
