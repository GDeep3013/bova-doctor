import React from 'react'
import EditPlan from '../../components/EditPlan'
export default function page() {
  return (
    <EditPlan/>
  )
}
