import CreatePlan from '../../components/CreatePlan'

export default function page() {
  return (
    <CreatePlan/>
  )
}