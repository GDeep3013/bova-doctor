import React from 'react'
import TermServices from './components/TermServices'

export default function page() {
    return (
      <TermServices/>
  )
}
