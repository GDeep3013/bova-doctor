import React from 'react'
import PageNotFound from './components/PageNotFound'

export default function page() {
  return (
    <PageNotFound/>
  )
}
