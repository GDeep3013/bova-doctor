
import Sales from './components/Sales'

export default function page() {
  return (
  <Sales/>
  )
}
